# Mayukh's Website — Complete Repackage Deployment Guide

## Summary
This package contains:
- **Adventure Data**: Gorumara Jeep Safari + Elephant Safari (2 entries)
- **Food Data**: Big Boss + Hotel Peljorling + Pizza Hut (3 entries)
- **Bhutan Journey**: Complete 12-destination travel data

## Files Included
1. `js/adventure-data-gorumara.js` — NEW adventure activities
2. `js/food-data.js` — NEW food photography entries
3. `js/bhutan-2015-journey.js` — NEW Bhutan journey (merge into travel-data.js)

## Deployment Steps

### Step 1: Copy Data Files to Device
```bash
# Copy adventure data
cp js/adventure-data-gorumara.js YOUR_DEVICE/mayukh-site/js/adventure-data.js

# Copy food data
cp js/food-data.js YOUR_DEVICE/mayukh-site/js/food-data.js
```

### Step 2: Merge Bhutan Journey into travel-data.js
- Open `js/bhutan-2015-journey.js` — copy the BHUTAN_2015_JOURNEY object
- Open YOUR_DEVICE/mayukh-site/js/travel-data.js
- Find the `journeys:` array
- Add BHUTAN_2015_JOURNEY to the journeys array (BEFORE the closing bracket)

### Step 3: Add Assets
Copy image files to:
- `assets/adventure/` — Gorumara Jeep Safari + Elephant Safari photos
- `assets/food/` — Big Boss + Pizza Hut + Hotel Peljorling photos
- `assets/travel/` — Bhutan destination photos (12 locations)

### Step 4: Git Commit & Push
```bash
cd your-device:/path/to/mayukh-site
git add .
git commit -m "Add Gorumara adventure activities, Bhutan 2015 journey, and food photography

- Gorumara Jeep Safari (2015-02-21)
- Gorumara Elephant Safari (2015-02-22)
- Bhutan 2015: 12 destinations (2015-02-14 to 2015-02-20)
- Food Photography: Big Boss (2014), Hotel Peljorling (2015), Pizza Hut (2015)"

git push origin main
```

## Data Summary

### Gorumara 2015 Adventure (NEW)
- **Jeep Safari**: 2015-02-21 09:00:00 | Coords: 26.7, 88.8 | Camera: SONY DSC-HX200V
- **Elephant Safari**: 2015-02-22 09:00:00 | Coords: 26.7, 88.8 | Camera: SONY DSC-HX200V

### Food Photography (NEW)
- **Big Boss Persian Kabab**: 2014 | Kolkata | Dinner
- **Hotel Peljorling Beef Stew**: 2015-02-16 13:48 | Paro, Bhutan | Lunch
- **Pizza Hut Chocolate Lava Cake**: 2015-06-27 21:37:18 | Kolkata | Dinner

### Bhutan 2015 (12 Destinations)
1. Phuntsholing (2015-02-14 13:47)
2. Chhuka (2015-02-14 16:00)
3. Thimphu (2015-02-15 13:43)
4. Chuzom (2015-02-16 11:41)
5. Paro Dzong (2015-02-16 11:53)
6. Tiger Nest Monastery (2015-02-17 09:02)
7. Drukgyal Dzong (2015-02-18 09:15)
8. Haa Valley (2015-02-18 16:03)
9. Kurjey Lhakhang (2015-02-20 06:06)
10. Punakha Dzong (2015-02-20 08:26)
11. Wangduephodrang (2015-02-20 11:33)

## Status
- ✅ Gorumara 2015 Wildlife (8 entries) — Already on GitHub
- ✅ Gorumara 2015 Travel Observation Tower — Already on GitHub
- 🟡 Gorumara 2015 Adventure (2 entries) — Ready to push
- 🟡 Bhutan 2015 (12 destinations) — Ready to push
- 🟡 Food Photography (3 entries) — Ready to push

All data is chronologically ordered by EXIF timestamp with precise GPS coordinates.
